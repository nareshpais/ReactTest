import Heading from "@/components/heading";

export default function PageProjects() {
  return (
    <Heading title="Projects" />
  )
}