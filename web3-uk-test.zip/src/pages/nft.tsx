import Heading from "@/components/heading";

export default function PageNft() {
  return (
    <Heading title="NFT" />
  )
}