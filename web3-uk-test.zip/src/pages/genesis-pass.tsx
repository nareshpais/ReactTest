import Heading from "@/components/heading";

export default function PageGenesisPass() {
  return (
    <Heading title="Genesis pass" />
  )
}