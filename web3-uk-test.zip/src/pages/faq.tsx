import Heading from "@/components/heading";

export default function PageFaq() {
  return (
    <Heading title="FAQ" />
  )
}